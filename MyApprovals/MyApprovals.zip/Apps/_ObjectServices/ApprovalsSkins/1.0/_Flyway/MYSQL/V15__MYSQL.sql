RENAME TABLE `User` TO `ConfigurationMaster`;
