ALTER TABLE `ConfigurationBundle`
	MODIFY `configurationBundle_id` BIGINT;
