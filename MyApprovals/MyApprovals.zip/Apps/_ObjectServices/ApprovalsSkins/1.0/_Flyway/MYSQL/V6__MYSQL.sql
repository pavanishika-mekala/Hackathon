ALTER TABLE `Configurations`
	MODIFY `configurationBundle_id` BIGINT;
