ALTER TABLE `ConfigurationBundle` ADD UNIQUE INDEX `id` (`bundle_id`,`id`);
