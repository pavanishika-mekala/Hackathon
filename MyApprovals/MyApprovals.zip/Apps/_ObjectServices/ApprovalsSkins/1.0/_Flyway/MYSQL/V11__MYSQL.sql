ALTER TABLE `ConfigurationBundle`
	CHANGE `configurationBundle_id` `bundle_id` BIGINT;
