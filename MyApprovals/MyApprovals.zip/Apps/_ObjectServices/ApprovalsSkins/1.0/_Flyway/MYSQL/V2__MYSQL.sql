RENAME TABLE `ConfigurationBundle` TO `Bundle`;
