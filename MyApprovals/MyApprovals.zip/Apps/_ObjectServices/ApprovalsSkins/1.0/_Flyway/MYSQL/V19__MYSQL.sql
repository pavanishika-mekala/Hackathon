ALTER TABLE `Configurations`
	CHANGE `key` `configkey` VARCHAR(50);
