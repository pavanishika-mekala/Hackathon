DROP TABLE `ConfigurationMaster`;
