ALTER TABLE `ConfigurationBundle`
	ADD `name` VARCHAR(10);
