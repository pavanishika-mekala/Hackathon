ALTER TABLE `Configurations`
	ADD `type` VARCHAR(30);
