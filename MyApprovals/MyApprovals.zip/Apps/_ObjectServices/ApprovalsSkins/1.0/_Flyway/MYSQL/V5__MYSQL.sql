ALTER TABLE `Configurations`
	ADD `configurationBundle_id` VARCHAR(10);
