ALTER TABLE `Configurations`
	MODIFY `key` VARCHAR(50),
	MODIFY `value` VARCHAR(2000);
