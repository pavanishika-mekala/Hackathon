ALTER TABLE `ConfigurationMaster`
	ADD `app_id` VARCHAR(50),
	ADD `app_version` VARCHAR(50);
