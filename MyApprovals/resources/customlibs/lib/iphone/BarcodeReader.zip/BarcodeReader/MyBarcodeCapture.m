//
//
//  ScanBarCodes
//
//  Created by Srinivas Vemula 7/20/2015
//  
// This code is used to scan barcodes using native iOS AVCapture classes. We do not need any third party libraries to do this job. This works only on iOS 7+ OS versions and it supports the below types of barcodes UPC-A
//  --> UPC-E
//  --> Code 39
//  --> Code 39 mod 43
//  --> Code 93
//  --> Code 128
//  --> EAN-8
//  --> EAN-13
//  --> Aztec
//  --> PDF417
//  --> QR

#import <AVFoundation/AVFoundation.h>
#import "MyBarcodeCapture.h"

@interface MyBarcodeCapture () <AVCaptureMetadataOutputObjectsDelegate>
{
    AVCaptureSession *_session;
    AVCaptureDevice *_device;
    AVCaptureDeviceInput *_input;
    AVCaptureMetadataOutput *_output;
    AVCaptureVideoPreviewLayer *_prevLayer;
    UIButton *closeButton;
    UIView *_highlightView;
    
}
@end

@implementation MyBarcodeCapture

- (void)viewDidLoad
{
    [super viewDidLoad];

    _highlightView = [[UIView alloc] init];
    _highlightView.autoresizingMask = UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleBottomMargin;
    _highlightView.layer.borderColor = [UIColor greenColor].CGColor;
    _highlightView.layer.borderWidth = 3;
    [self.view addSubview:_highlightView];

    
    closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [closeButton setFrame:CGRectMake(0, self.view.bounds.size.height - 40, self.view.bounds.size.width, 40)];
    closeButton.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    [closeButton setTitle:@"Close" forState:UIControlStateNormal];
    [closeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [closeButton.titleLabel setFont:[UIFont systemFontOfSize:18]];
    [closeButton addTarget:self action:@selector(closeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [closeButton setBackgroundColor: [UIColor grayColor]];
    [self.view addSubview:closeButton];

    _session = [[AVCaptureSession alloc] init];
    _device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    NSError *error = nil;

    _input = [AVCaptureDeviceInput deviceInputWithDevice:_device error:&error];
    if (_input) {
        [_session addInput:_input];
    } else {
        NSLog(@"Error: %@", error);
    }

    _output = [[AVCaptureMetadataOutput alloc] init];
    [_output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    [_session addOutput:_output];

    _output.metadataObjectTypes = [_output availableMetadataObjectTypes];

    _prevLayer = [AVCaptureVideoPreviewLayer layerWithSession:_session];
    _prevLayer.frame = self.view.frame;
    _prevLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    _prevLayer.bounds=self.view.bounds;
    _prevLayer.position=CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds));
    [self.view.layer addSublayer:_prevLayer];

    [_session startRunning];

    [self.view bringSubviewToFront:_highlightView];
    [self.view bringSubviewToFront:closeButton];
}

-(IBAction)closeButtonAction:(id)sender{
    [_session release];
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

// This method will be called once all the subviews are loaded. Using this method we are changing the orientation of camera preview layer.

- (void)viewDidLayoutSubviews
{
    CGRect bounds=self.view.layer.bounds;
    _prevLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    _prevLayer.bounds=bounds;
    _prevLayer.position=CGPointMake(CGRectGetMidX(bounds), CGRectGetMidY(bounds));
    //_prevLayer.orientation = [[UIDevice currentDevice] orientation];
    [closeButton setFrame:CGRectMake(0, self.view.bounds.size.height - 40, self.view.bounds.size.width, 40)];
    
    
}

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    [super willRotateToInterfaceOrientation:toInterfaceOrientation duration:duration];
    
    AVCaptureConnection *videoConnection = _prevLayer.connection;
    [videoConnection setVideoOrientation:(AVCaptureVideoOrientation)toInterfaceOrientation];
    
}

// This method will be called once the output is captured. We are using this method to call callback function with the captured value.
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection
{
    
    NSMutableArray *valueOfDic;
    CGRect highlightViewRect = CGRectZero;
    AVMetadataMachineReadableCodeObject *barCodeObject;
    NSString *detectionString = nil;
    NSArray *barCodeTypes = @[AVMetadataObjectTypeUPCECode, AVMetadataObjectTypeCode39Code, AVMetadataObjectTypeCode39Mod43Code,
            AVMetadataObjectTypeEAN13Code, AVMetadataObjectTypeEAN8Code, AVMetadataObjectTypeCode93Code, AVMetadataObjectTypeCode128Code,
            AVMetadataObjectTypePDF417Code, AVMetadataObjectTypeQRCode, AVMetadataObjectTypeAztecCode];

    for (AVMetadataObject *metadata in metadataObjects) {
        for (NSString *type in barCodeTypes) {
            if ([metadata.type isEqualToString:type])
            {
                barCodeObject = (AVMetadataMachineReadableCodeObject *)[_prevLayer transformedMetadataObjectForMetadataObject:(AVMetadataMachineReadableCodeObject *)metadata];
                highlightViewRect = barCodeObject.bounds;
                detectionString = [(AVMetadataMachineReadableCodeObject *)metadata stringValue];
                break;
            }
        }

        if (detectionString != nil)
        {
            
            NSMutableDictionary * infoTable = [NSMutableDictionary dictionary];
            [infoTable setObject:detectionString forKey:@"barcodestring"];
            valueOfDic = [[NSMutableArray alloc] initWithObjects:infoTable, nil];
            [_session removeConnection:connection];
            [_session release];
            [self dismissViewControllerAnimated:YES completion:nil];
            executeClosure(self.barcodeCallback, valueOfDic, false);
            break;
        }
        
    }

    _highlightView.frame = highlightViewRect;
}

@end