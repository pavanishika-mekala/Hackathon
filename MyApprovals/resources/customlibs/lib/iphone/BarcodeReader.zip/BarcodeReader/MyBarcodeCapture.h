//

//  ScanBarCodes
//
//  Created by Srinivas Vemula 7/20/2015.
// 
//

#import <UIKit/UIKit.h>
#import "lglobals.h"

@interface MyBarcodeCapture : UIViewController

@property (strong) CallBack *barcodeCallback;

@end