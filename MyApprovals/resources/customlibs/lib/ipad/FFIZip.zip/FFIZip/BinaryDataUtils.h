//
//  BinaryDataUtils.h
//  BinaryDataManager
//
//  Created by MBAAS on 14/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BinaryDataUtils : NSObject

+ (NSMutableDictionary *)getMetadataForDownloadTask: (NSString *)blobId withConfig: (NSDictionary *)config;

@end
