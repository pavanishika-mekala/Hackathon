//
//  ErrorConstants.h
//  BinaryDataManager
//
//  Created by MADP on 07/11/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

//Error codes..
FOUNDATION_EXPORT int const kCodeInvalidStateForBinaryOperation;
FOUNDATION_EXPORT int const kCodeInvalidStateForDownloadTaskCreation;
FOUNDATION_EXPORT int const kCodeDownloadTaskNotCreated;
FOUNDATION_EXPORT int const kCodeBinaryRecordDoesNotExist;
FOUNDATION_EXPORT int const kCodeNullDownloadTaskIDReceived;
FOUNDATION_EXPORT int const kCodeTaskAlreadyStartedException;

//Network error codes
FOUNDATION_EXPORT int const kCodeFailedToConnectToServer;
FOUNDATION_EXPORT int const kCodeBinaryDownloadFailed;
FOUNDATION_EXPORT int const kCodeHTTPRequestFailed;
FOUNDATION_EXPORT int const kCodeContentRangeNotReceived;

//Delete binary error codes.
FOUNDATION_EXPORT int const kCodeSQLiteExecuteFailed;

@interface ErrorConstants : NSObject

@end
