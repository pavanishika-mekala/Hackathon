#import "PDFPageRenderer.h"
#import "sample.h"
#import "fcntl.h"

@implementation TestClass

- (id) init{
	
	if( self = [super init] )
    {
        // Initialize your object here
    }
	return self;
}
static CGPDFDocumentRef pdfDoc=nil;
static NSInteger pagecount;
+ (NSInteger) downloadFile: (NSString*) filepath {
    
   
  NSLog(@"';';';';';';';';';';';';';'The file is downloaded to the path %@",filepath);
    
   
       
		NSLog(@"';';';';';';';';';';;';;';';';';';';';';';';The file is downloaded to the path %@",filepath);
		const char *inputPDFFileAsCString = [filepath cStringUsingEncoding:NSASCIIStringEncoding];
		CFStringRef path = CFStringCreateWithCString(NULL, inputPDFFileAsCString, kCFStringEncodingUTF8);
		
		CGContextRef    context = NULL;
		CFURLRef url = CFURLCreateWithFileSystemPath(context, path, kCFURLPOSIXPathStyle, 0);
		NSLog(@"';';';';';';';';';';';';';';'';';';';The file is downloaded to the path %@",path);
		CFRelease (path);
		
		pdfDoc = CGPDFDocumentCreateWithURL(url);
		CFRelease(url);
		
		if(pdfDoc!=NULL)
		{
			pagecount=CGPDFDocumentGetNumberOfPages(pdfDoc);			
		}
	return pagecount;
}

+ (NSString*) openPage: (NSInteger) pageNo {
if(pageNo>pagecount||pageNo<1)
	return @"Invalid PageNo";
	CGPDFPageRef page=CGPDFDocumentGetPage(pdfDoc,pageNo);
	
	CGRect cropBox = CGPDFPageGetBoxRect(page, kCGPDFCropBox);
	int pageRotation = CGPDFPageGetRotationAngle(page);
	
	if ((pageRotation == 0) || (pageRotation == 180) ||(pageRotation == -180)) {
		UIGraphicsBeginImageContextWithOptions(cropBox.size, NO, 10 / 72); 
	}
	else {
		UIGraphicsBeginImageContextWithOptions(CGSizeMake(cropBox.size.height, cropBox.size.width), NO, 10 / 72); 
	}
	
	CGContextRef imageContext = UIGraphicsGetCurrentContext();   
	
    [PDFPageRenderer renderPage:page inContext:imageContext];
	
    UIImage *pageImage = UIGraphicsGetImageFromCurrentImageContext();  	
	
    UIGraphicsEndImageContext();
	
	NSString *signatureString = [UIImagePNGRepresentation(pageImage) base64EncodedStringWithOptions:0];
	NSLog(@"#########################################");
	NSLog(@"';';';';';';';';';';';';';';'';';';';Image generated is %@",signatureString);
	return signatureString;
	
	//else
	//return @"no img generated";
}

@end