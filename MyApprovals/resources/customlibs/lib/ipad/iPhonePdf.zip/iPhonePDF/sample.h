
@interface TestClass : NSObject

+(NSInteger) downloadFile: (NSString*) urltofile;
+(NSString*) openPage: (NSInteger) pageNo;

@end
