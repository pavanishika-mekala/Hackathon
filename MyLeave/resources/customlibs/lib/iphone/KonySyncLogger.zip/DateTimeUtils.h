//
//  DateTimeUtils.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.

//  Copyright © 2016 kony. All rights reserved.
//

/**
 * Utilities for Date and Time operations
 */
#import <Foundation/Foundation.h>

@interface DateTimeUtils :NSObject

/**
 * This a class method that generates a string representing the current timestamp.
 * @return the timestamp string
 */
+ (NSString *) getCurrentTimeStamp;

@end
