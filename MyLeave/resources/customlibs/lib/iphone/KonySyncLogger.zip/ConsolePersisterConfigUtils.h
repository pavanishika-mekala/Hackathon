//
//  ConsolePersisterConfig.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.
//
//  Created by Harshini Bonam on 09/09/16.

//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LoggerError.h"

@interface ConsolePersisterConfigUtils : NSObject

+ (BOOL) validateConsolePersisterConfig:(NSDictionary *)consolePersisterConfig
                               error:(LoggerError **)error;

@end
