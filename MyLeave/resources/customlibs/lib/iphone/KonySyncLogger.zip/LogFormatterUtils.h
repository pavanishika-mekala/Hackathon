//
//  LogFormatterUtils.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.

//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LoggerError.h"
#import "FormatError.h"
#import "LogStatement.h"
#import "TimeZonePreferences.h"

@interface LogFormatterUtils :NSObject

+ (TimeZonePreference) getTimeZone:(NSString *) timeZoneString
                         error:(LoggerError **) error;
+ (NSString *)formatStringWithLogStatement:(LogStatement *)statement
                             configuration:(NSDictionary *)config
                                     error:(FormatError **)error;

@end
