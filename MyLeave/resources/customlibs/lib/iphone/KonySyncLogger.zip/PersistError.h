//
//  PersistError.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import "LoggerError.h"

/**
 The PersistError is a specific error class derived from LoggerError class
 that provides errorCode, errrorDomain, errorInfo and errorCause.
 */
@interface PersistError :LoggerError

/*
 * If shouldExit property is set YES, then the current context that is being persisted will be terminated,
 * otherwise the context will continue to persist in the next statements in the context.
 */
@property BOOL shouldExit;

@end
