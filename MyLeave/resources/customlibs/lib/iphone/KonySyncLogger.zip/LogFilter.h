//
//  LogFilter.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LogLevelConstants.h"

@class LogStatement;
@class LoggerError;
@protocol LogFilterListener;

@interface LogFilter :NSObject

@property (nonatomic, readwrite) LogLevel logLevel;

#pragma mark - init methods
- (instancetype)init;

#pragma mark - process method
- (void)setLogLevel:(LogLevel)logLevel;
- (NSUInteger)getLogLevel;
- (void)process:(LogStatement *)statement
          error:(LoggerError **)error;

#pragma mark - (un)subscribe methods
- (void)subscribeForUpdates:(id <LogFilterListener>)listener;
- (void)unsubscribeForUpdates:(id <LogFilterListener>)listener;
- (void)unsubscribeAll;

@end
