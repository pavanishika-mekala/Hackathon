//
//  LogFilterListener.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LogFilter;
@class LogStatement;

@protocol LogFilterListener <NSObject>

@required
- (void)filter:(LogFilter *)filter filteredStatement:(LogStatement *)statement;
- (void)filter:(LogFilter *)filter unfilteredStatement:(LogStatement *)statement;

@end
