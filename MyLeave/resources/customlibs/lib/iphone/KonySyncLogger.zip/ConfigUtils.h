//
//  ConfigUtils.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LoggerError.h"
@interface ConfigUtils :NSObject
+ (BOOL)config:(NSDictionary *)config
       hasKeys:(NSArray *)requiredKeys
         error:(LoggerError **)error;

+ (BOOL)validateValueTypeInConfig:(NSDictionary *)config
               withRequiredConfig:(NSDictionary *)requiredConfig
                            error:(LoggerError **)error;

@end
