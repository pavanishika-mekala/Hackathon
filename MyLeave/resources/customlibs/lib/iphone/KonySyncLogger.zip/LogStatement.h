//
//  LogStatement.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.

//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LogLevelConstants.h"
#import "LoggerError.h"

@interface LogStatement :NSObject

/**
 * LogLevel for the logging statement
 */
@property (nonatomic, readwrite) LogLevel logLevel;

- (instancetype) initWithLogLevel:(LogLevel) logLevel
                        Statement:(NSString *)logStatement
                            Error:(LoggerError **)error;

- (NSDate *)getDate;
- (NSString *)getLogStatement;


@end
