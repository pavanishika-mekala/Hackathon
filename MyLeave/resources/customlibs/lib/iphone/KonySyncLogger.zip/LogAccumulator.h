//
//  LogAccumulator.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LogFilterListener.h"

/**
 The LogAccumulator Class is a LogFilterListerner that notifies the accumulator instance with the (un)filtered logStatements. The accumulator accumulates the log statements in it until the flush condition is met.
 
 The instances methods exposed are:
    - (instancetype)initWithConfig:(NSDictionary *)config;
    - (void)flush;
    - (void)subscribeListener:(id <IAccumulatorListener>)listener;
    - (void)unsubscribeListener:(id <IAccumulatorListener>)listener;
    - (void)unsubscribeAll;

 */

@protocol IAccumulatorListener;

@interface LogAccumulator :NSObject <LogFilterListener>

/**-----------------------------------------------------------------------------
 * @name Initialization
 * @return instance Instance of the accumulator.
 * -----------------------------------------------------------------------------
 */

#pragma mark - init methods
- (instancetype)initWithConfig:(NSDictionary *)config;

/**-----------------------------------------------------------------------------
 * @name flush
 * Flushes the accumulated state to the registered listeners.
 * -----------------------------------------------------------------------------
 */
#pragma mark - main methods
- (void)flush;

/**-----------------------------------------------------------------------------
 * @name subscription methods
 * Methods to subscribe and unsubscribe the accumulator's listeners.
 * -----------------------------------------------------------------------------
 */
#pragma mark - (un)subscription methods
- (void)subscribeListener:(id <IAccumulatorListener>)listener;
- (void)unsubscribeListener:(id <IAccumulatorListener>)listener;
- (void)unsubscribeAll;

//Helper methods for Unit testing
- (NSInteger)subscribedListenersCount;

@end
