//
//  BinaryDataManagerConstants.h
//  BinaryDataManager
//
//  Created by MADP on 27/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT int const kDownloadNotStarted;
FOUNDATION_EXPORT int const kDownloadStarted;
FOUNDATION_EXPORT int const kDownloadErrored;
FOUNDATION_EXPORT int const kDownloadPaused;
FOUNDATION_EXPORT int const kFileAvailable;
FOUNDATION_EXPORT int const kDeleteAccepted;

FOUNDATION_EXPORT NSString *const kKonySyncBlobStoreMangager;



@interface BinaryDataManagerConstants : NSObject

@end