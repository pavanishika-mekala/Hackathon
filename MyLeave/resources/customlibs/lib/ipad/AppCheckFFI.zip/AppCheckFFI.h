#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "lglobals.h"

@interface AppCheckFFI : UIViewController

+(id)init;
-(BOOL)isAppInstalled:(NSString*)appScheme;

@end