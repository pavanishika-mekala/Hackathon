
#import "AppCheckFFI.h"

@implementation AppCheckFFI

+(id)init
{
    static AppCheckFFI *reader = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        reader = [[self alloc] init];
    });
    return reader;
 
}
-(BOOL)isAppInstalled:(NSString *)appScheme
{
	UIApplication *app = [UIApplication sharedApplication];
    
    NSURL *appurl = [NSURL URLWithString:appScheme];
	
    return [app canOpenURL:appurl];
}

@end
