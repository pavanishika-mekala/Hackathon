//
//  KonyException.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LoggerExceptionConstants.h"


/**
 The LoggerError is a custom NSError class that provides errorCode, errrorDomain, errorInfo and errorCause.
 
 The instances methods exposed are:
 - (instancetype)initWithErrorCode:(NSUInteger)errorCode domain:(NSString *)errorDomain context:(NSDictionary *)errorInfo;
 - (NSString *)getDescription;
 - (NSString *)recursiveDescription;
 
 */
@interface LoggerError :NSError

@property (nonatomic, assign)NSUInteger errorCode;
@property (nonatomic, retain)NSMutableString *errorDomain;
@property (nonatomic, retain)NSMutableDictionary *errorInfo;
@property (nonatomic, retain)LoggerError *errorCause;

#pragma mark - init method
/**-----------------------------------------------------------------------------
 * @name initialization method.
 * @param errorCode The error code of the specific error.
 * @param errorDomain The error domain in which the error occured.
 * @param errorInfo The error information describing more about the error.
 * -----------------------------------------------------------------------------
 */
- (instancetype)initWithErrorCode:(NSUInteger)errorCode
                           domain:(NSString *)errorDomain
                          context:(NSDictionary *)errorInfo;

#pragma mark - error description methods
/**-----------------------------------------------------------------------------
 * @name getDescription method.
 * Used to get the description of an error.
 * @return errorDescriptiveString Contains the errorCode, errorDomain and Description.
 * -----------------------------------------------------------------------------
 */
- (NSString *)getDescription;

/**-----------------------------------------------------------------------------
 * @name recursiveDescription method.
 * Used to get the description of an error along with its subsequent error cause if exists.
 * @return errorDescriptiveString Contains the errorCode, errorDomain and Description.
 * -----------------------------------------------------------------------------
 */
- (NSString *)recursiveDescription;

@end
