//
//  LogLevelUtils.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.
//  Created by MADP on 21/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LoggerError.h"
#import "LogLevelConstants.h"

@interface LogLevelUtils :NSObject

@property (nonatomic, readwrite) LogLevel logLevel;

+ (NSString *)getLogLevel:(LogLevel)logLevel
                 withError:(LoggerError **)error;

@end
