//
//  KonySDKLogger.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CallBack.h"

/**
 The KonySyncLogger Class is the FFI layer class that exposes the Logging APIs to the Javascript layer.
 The static methods exposed are:
    + (void)setConfig:(NSDictionary *)loggerConfig errorCallback:(CallBack *)errorCallback;
    + (void)addPersister:(NSDictionary *) persisterConfig errorCallback:(CallBack *)errorCallback;
    + (void)setLogLevel:(NSUInteger *)logLevel;
    + (int)getLogLevel;
    + (void)flush;
    + (void)logTrace:(NSString *) statement;
    + (void)logDebug:(NSString *) statement;
    + (void)logWarning:(NSString*) statement;
    + (void)logInfo:(NSString *) statement;
    + (void)logError:(NSString *) statement;
    + (void)logFatal:(NSString *) statement;
 
 */
@interface KonySyncLogger :NSObject


/**-----------------------------------------------------------------------------
 * @name Setting the logger config through FFI layer.
 * -----------------------------------------------------------------------------
 */

/**
 Sets the loggerConfig to the loggerEngine.
 This is the first method that must be invoked to initialize the logger engine.
 @param loggerConfig The logger configuration for the loggerEngine, containing logFilterConfig and LogAccumulatorConfig.
 @param errorCallback a nullable method passed as a parameter, invoked in case of error otherwise logged on the console.
 */
+ (void)setConfig:(NSDictionary *)loggerConfig
    errorCallback:(CallBack *)errorCallback;

/**-----------------------------------------------------------------------------
 * @name Adding the persister through FFI layer.
 * -----------------------------------------------------------------------------
 */

/**
 Adds persisterConfig to the the loggerEngine.
 This method can be invoked any number of times to add multiple persisters each time.
 @param persisterConfig The persister configuration for the loggerEngine, containing persisterType, and its properties.
 @param errorCallback a nullable method passed as a parameter, invoked in case of error otherwise logged on the console.
 */
+ (void)addPersister:(NSDictionary *) persisterConfig
       errorCallback:(CallBack *)errorCallback;

/**-----------------------------------------------------------------------------
 * @name Main logging utilities through FFI layer.
 * -----------------------------------------------------------------------------
 */

/**
 * SET LOG LEVEL 
 * @param logLevel logLevel to be set to logFilter
 */
+ (void)setLogLevel:(NSUInteger *)logLevel;

/**
 * GET LOG LEVEL
 * @return logLevel logLevel set to logFilter
 */
+ (int)getLogLevel;

/**
 * FLUSH the accumulated logs.
 */
+ (void)flush;
/**
 * TRACE statement
 * @param statement Statement to be logged
 */
+ (void)logTrace:(NSString *) statement;

/**
 * DEBUG statement
 * @param statement Statement to be logged
 */
+ (void)logDebug:(NSString *) statement;

/**
 * WARNING statement
 * @param statement Statement to be logged
 */
+ (void)logWarning:(NSString*) statement;

/**
 * INFO statement
 * @param statement Statement to be logged
 */
+ (void)logInfo:(NSString *) statement;

/**
 * ERROR statement
 * @param statement Statement to be logged
 */
+ (void)logError:(NSString *) statement;

/**
 * FATAL statement
 * @param statement Statement to be logged
 */
+ (void)logFatal:(NSString *) statement;


@end
