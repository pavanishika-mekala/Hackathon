//
//  KonySDKLoggerUtils.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.

//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CallBack.h"
#import "LoggerError.h"

@interface LoggerUtils :NSObject

+ (void)modifyTimeZone:(NSMutableDictionary *)properties;

+ (void)handleError:(LoggerError *) error;

+ (void)handleError:(LoggerError *) error
  withErrorCallback:(CallBack *)errorCallback;

+ (NSString *)getiOSPath;

+ (void)printStackTrace;
@end
