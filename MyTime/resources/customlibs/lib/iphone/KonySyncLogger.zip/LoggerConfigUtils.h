//
//  LoggerConfigUtils.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.

//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LoggerError.h"
#import "LogLevelConstants.h"

@interface LoggerConfigUtils :NSObject


+ (BOOL)validateLoggerConfig:(NSDictionary *)loggerConfig
                       error:(LoggerError **)error;
+ (BOOL)validateLogLevel:(NSUInteger *)logLevel
                   error:(LoggerError **)error;
@end
