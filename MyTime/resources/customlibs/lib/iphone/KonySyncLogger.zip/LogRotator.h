//
//  LogRotator.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.

//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * Utils for handling log rotation
 */
@interface LogRotator :NSObject

/**
 * Constructor
 * @param logsDumpLocation Location where the log files are to be dumped
 * @param prefix The prefix for logfile names
 * @param maxLogFileSize Maximum size of log files
 * @param maxNumberOfLogFiles Maximum number of log files to be retained
 */
- (instancetype)initWithFilePrefix:(NSString *)fileNamePrefix
          logsDumpLocation:(NSString *)logsDumpLocation
       maxNumberofLogFiles:(NSUInteger)maxNumberOfLogFiles
            maxLogFileSize:(NSUInteger)maxLogFileSize;

- (void)rotateLogFile;
- (NSString *)getCurrentLogFile;
- (NSFileHandle *)getCurrentLogFileHandle;

- (NSString *) getLogDumpLocation;
@end
