//
//  PersisterUtils.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.

//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LoggerError.h"

@interface FilePersisterConfigUtils :NSObject


+ (BOOL) validateFilePersisterConfig:(NSDictionary *)filePersisterConfig
                           error:(LoggerError **)error;

@end
