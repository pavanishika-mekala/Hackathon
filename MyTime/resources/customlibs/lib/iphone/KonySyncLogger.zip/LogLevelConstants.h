//
//  LogLevelConstants.h
//  Logger
//
//  Created by Harshini Bonam on 26/08/16.
//  Copyright © 2016 kony. All rights reserved.
//


/**
 * Log levels for the Logger
 */
#import <Foundation/Foundation.h>

typedef NS_OPTIONS(NSUInteger, LogLevel) {
    /**
     * Logs Nothing
     */
    LogLevelNone        = 0,
    
    /**
     * Logs Traces
     */
    LogLevelTrace       = 1 << 0,
    
    /**
     * Logs messages relevant to debugging of code (by developers)
     */
    LogLevelDebug       = 1 << 1,
    
    /**
     * Logs Info
     */
    LogLevelInfo        = 1 << 2,
    
    /**
     * Logs Warnings 
     */
    LogLevelWarning     = 1 << 3,
    
    /**
     * Logs errors
     */
    LogLevelError       = 1 << 4,
    
    /**
     * Logs Fatals
     */
    LogLevelFatal       = 1 << 5,
    
    /**
     * Logs Fatals and above.
     */
    LogLevelFatalAndAbove   = LogLevelFatal,
    
    /**
     * Logs Errors and above.
     */
    LogLevelErrorAndAbove   = (LogLevelFatalAndAbove |
                               LogLevelError),
    
    /**
     * Logs Warnings and above.
     */
    LogLevelWarningAndAbove = (LogLevelErrorAndAbove |
                               LogLevelWarning),
    
    /**
     * Logs Info and above.
     */
    LogLevelInfoAndAbove    = (LogLevelWarningAndAbove |
                               LogLevelInfo),
    
    /**
     * Logs Debug and above.
     */
    LogLevelDebugAndAbove   = (LogLevelInfoAndAbove |
                               LogLevelDebug),
    
    /**
     * Logs Traces and above.
     */
    LogLevelTraceAndAbove   = (LogLevelDebugAndAbove |
                               LogLevelTrace),
    
    /**
     * Logs every level of log statements
     */
    LogLevelAll         = LogLevelTraceAndAbove
};

@interface LogLevelConstants :NSObject

@end
