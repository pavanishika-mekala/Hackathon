//
//  KonyExceptionConstants.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

/**
 * Constants for Kony Exceptions.
 */
#import <Foundation/Foundation.h>

/**
 * Generic error codes
 * Error codes between (0-99)
 */

extern NSUInteger const KEY_NOTFOUND;
extern NSUInteger const KEY_VALUE_TYPE_MISMATCH;
extern NSUInteger const LOGGER_ENGINE_NOT_INITIALIZED;
extern NSUInteger const LOG_ACCUMULATOR_NOT_INITIALIZED;
extern NSUInteger const LOG_FILTER_NOT_INITIALIZED;

extern NSUInteger const LOG_STATEMENT_NOT_INITIALIZED;
extern NSUInteger const EMPTY_LOG_STATEMENT;
extern NSUInteger const EMPTY_CONFIG;

/**
 * Logger config error codes
 * Error codes between (100 - 199)
 */
extern NSUInteger const INVALID_LOGGER_CONFIG;
extern NSUInteger const INVALID_FILTER_CONFIG;
extern NSUInteger const INVALID_ACCUMULATOR_CONFIG;

extern NSUInteger const INVALID_LOGLEVEL;
extern NSUInteger const LOGGER_CONFIG_KEY_VALUE_NOTFOUND;
extern NSUInteger const LOGGER_CONFIG_KEY_VALUE_TYPE_MISMATCH;
extern NSUInteger const CANNOT_PROCESS_LOG_STATEMENT;

extern NSUInteger const INVALID_BYTES_LIMIT;
extern NSUInteger const INVALID_STATEMENT_COUNT_LIMIT;

/**
 * Persister config error codes
 * Error codes between (200 - 299);
 */
extern NSUInteger const INVALID_PERSISTER_CONFIG;
extern NSUInteger const INVALID_PERSISTER_PROPERITES;
extern NSUInteger const INVALID_FORMATTER_CONFIG;
extern NSUInteger const INVALID_PERSISTER_TYPE;
extern NSUInteger const PERSISTER_CONFIG_KEY_NOTFOUND;
extern NSUInteger const PERSISTER_CONFIG_KEY_VALUE_TYPE_MISMATCH;
extern NSUInteger const INVALID_MAX_LOGFILE_SIZE;
extern NSUInteger const INVALID_MAX_LOGFILES;
extern NSUInteger const INVALID_DUMPLOCATION;
extern NSUInteger const INVALID_FILENAME_PREFIX;
extern NSUInteger const INVALID_LOGNAME;
extern NSUInteger const INVALID_TIMEZONE_FORMAT;
extern NSUInteger const INVALID_TIMEZONE_PREFERENCE;

/**
 * Error code between (300 - 399)
 */
extern NSUInteger const RECEIVED_EMPTY_FILE_HANDLE;
extern NSUInteger const FORMAT_ERROR;
extern NSUInteger const PERSIST_ERROR;

@interface LoggerExceptionConstants :NSObject
/**
 * Class method to retrieve the Error statement based on error code.
 * @param code the error code
 */
+ (NSString *)getStringWithCode:(NSUInteger) code;

@end
