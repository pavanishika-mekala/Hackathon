//
//  LoggerEngine.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 The LoggerEngine class takes the input logger configuration and starts the logger engine, adds the persisters configuration as well.
 The instance methods exposed are: 
    - (instancetype)init;
    - (void)setConfig:(NSDictionary *)config error:(LoggerError **)error;
    - (BaseLogPersister *)addPersister:(NSDictionary *)persisterConfig error:(LoggerError **)error;
    - (void)setLogLevel:(NSUInteger *)logLevel;
    - (NSUInteger)getLogLevel;
    - (void)processLogStatement:(LogStatement *)statement error:(LoggerError **)error;
    - (void)flushWithError:(LoggerError **)error;
 */

@class LogStatement;
@class LoggerError;
@class BaseLogPersister;

@interface LoggerEngine :NSObject

@property (nonatomic, copy) NSDictionary *config;

/**-----------------------------------------------------------------------------
 * @name Setting the logger config through LoggerEngine.
 * -----------------------------------------------------------------------------
 */

/**
 Sets the loggerConfig to the loggerEngine.
 This is the first method that must be invoked to initialize the logger engine.
 @param loggerConfig The logger configuration for the loggerEngine, containing logFilterConfig and LogAccumulatorConfig.
 @param error a nullable LoggerError instance passed as a parameter, assigned with an errorCode, errorDomain, errorDescription and errorCause(optional)  in case of error,can also be logged on the console.
 */
- (void)setConfig:(NSDictionary *)config
            error:(LoggerError **)error;

/**-----------------------------------------------------------------------------
 * @name Adding the persister through LoggerEngine.
 * -----------------------------------------------------------------------------
 */

/**
 Adds persisterConfig to the the loggerEngine.
 This method can be invoked any number of times to add multiple persisters each time.
 @param persisterConfig The persister configuration for the loggerEngine, containing persisterType,  and LogAccumulatorConfig.
 @param errorCallback a nullable method passed as a parameter, invoked in case of containing persisterType, and its properties.
 */
- (BaseLogPersister *)addPersister:(NSDictionary *)persisterConfig
                             error:(LoggerError **)error;

/**-----------------------------------------------------------------------------
 * @name Main logging utilities through facade layer.
 * -----------------------------------------------------------------------------
 */

/**
 * SET LOG LEVEL
 * @param logLevel logLevel to be set to logFilter
 */
- (void)setLogLevel:(NSUInteger *)logLevel;

/**
 * GET LOG LEVEL
 * @return logLevel logLevel set to logFilter
 */
- (NSUInteger)getLogLevel;

/**
 The master method for logging
 @param statement Statement to be logged
 @param logLevel Level of logging for the input statement
 */
- (void)processLogStatement:(LogStatement *)statement
                      error:(LoggerError **)error;
/**
 * FLUSH the accumulated logs.
 */
- (void)flushWithError:(LoggerError **)error;

@end
