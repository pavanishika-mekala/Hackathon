#import "WrapperForiToast.h"
#import "iToast.h"

@implementation WrapperForiToast

+ (void) showTstMessage: (NSString*) message forDuration: (NSNumber *) duration {
    
[[[[iToast makeText:message] setGravity:iToastGravityBottom] setDuration:duration] show];
    
}

@end
