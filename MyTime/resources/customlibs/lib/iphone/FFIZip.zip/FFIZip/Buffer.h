//
//  Buffer.h
//  TaskFrameworkLibrary
//
//  Created by MADP on 15/09/16.
//  Copyright © 2016 MADP. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Chunk.h"

@interface Buffer : NSObject

- (instancetype)init;
- (void)addChunkToBuffer: (Chunk *)chunk;
- (Chunk *)removeChunkFromBuffer;
- (BOOL)isBufferEmpty;

@end
